#ifndef NET_MINECRAFT_WORLD_LEVEL_TILE__BackroomsTiles_H__
#define NET_MINECRAFT_WORLD_LEVEL_TILE__BackroomsTiles_H__

// The five blocks that only exist in the Backrooms dimension.
//   floor      - damp yellow carpet
//   wall       - striped wallpaper
//   ceiling    - pale ceiling tile
//   lamp (on)  - fluorescent panel, gives off light
//   lamp (off) - burnt-out panel, gives off no light
//
// Their pictures live in the game's terrain atlas. tools/apply_backrooms.py stamps
// the pictures into terrain.png at build time and writes BackroomsAtlas.h, which
// says which atlas square each picture went into.

#include "Tile.h"
#include "../material/Material.h"
#include "BackroomsAtlas.h"

// One Backrooms block. Unbreakable, so it never needs an item to drop.
class BackroomsTile: public Tile
{
public:
	BackroomsTile(int id, int texIndex, float light)
	:	Tile(id, Material::stone)
	{
		tex = texIndex;
		setDestroyTime(-1.0f);
		if (light > 0.0f) setLightEmission(light);
	}
};

class BackroomsTiles
{
public:
	// How bright the lit panels are: 0.8 of the maximum, which is light level 12 out of 15.
	// Raise it toward 1.0 for brighter, lower it for dimmer.
	static float lampBrightness() { return 0.8f; }

	static void init() {
		Tile** t = slots();
		if (t[0] != 0) return; // already made

		const int tex[5]    = { BR_TEX_FLOOR, BR_TEX_WALL, BR_TEX_CEILING, BR_TEX_LAMP_ON, BR_TEX_LAMP_OFF };
		const float lit[5]  = { 0.0f, 0.0f, 0.0f, lampBrightness(), 0.0f };

		int id = 180;
		for (int i = 0; i < 5; ++i) {
			while (id < 255 && Tile::tiles[id] != 0) ++id; // skip ids already taken
			t[i] = new BackroomsTile(id, tex[i], lit[i]);
			++id;
		}
	}

	static int floorId()   { init(); return slots()[0]->id; }
	static int wallId()    { init(); return slots()[1]->id; }
	static int ceilingId() { init(); return slots()[2]->id; }
	static int lampOnId()  { init(); return slots()[3]->id; }
	static int lampOffId() { init(); return slots()[4]->id; }

private:
	static Tile** slots() {
		static Tile* s[5] = { 0, 0, 0, 0, 0 };
		return s;
	}
};

#endif /*NET_MINECRAFT_WORLD_LEVEL_TILE__BackroomsTiles_H__*/
