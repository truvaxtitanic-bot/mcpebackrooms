#ifndef NET_MINECRAFT_WORLD_LEVEL_TILE__BackroomsAtlas_H__
#define NET_MINECRAFT_WORLD_LEVEL_TILE__BackroomsAtlas_H__
// Default values. tools/apply_backrooms.py overwrites this file at build time with the
// atlas squares it really used.
#define BR_TEX_FLOOR    255
#define BR_TEX_WALL     254
#define BR_TEX_CEILING  253
#define BR_TEX_LAMP_ON  252
#define BR_TEX_LAMP_OFF 251
#endif
