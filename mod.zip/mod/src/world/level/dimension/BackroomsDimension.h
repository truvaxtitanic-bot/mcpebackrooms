#ifndef NET_MINECRAFT_WORLD_LEVEL_DIMENSION__BackroomsDimension_H__
#define NET_MINECRAFT_WORLD_LEVEL_DIMENSION__BackroomsDimension_H__

#include "Dimension.h"
#include "../Level.h"
#include "../levelgen/BackroomsLevelSource.h"

class BackroomsDimension: public Dimension
{
public:
	static const int BACKROOMS = 2;

	BackroomsDimension() {
		id = BACKROOMS;
		hasCeiling = true;
	}

	ChunkSource* createRandomLevelSource() {
		return new BackroomsLevelSource(level);
	}

	bool isValidSpawn(int x, int z) { return true; }

	// Always the same light level; there is no sun down here.
	float getTimeOfDay(long time, float a) { return 0.5f; }

	// A dull yellow haze.
	Vec3 getFogColor(float td, float a) { return Vec3(0.52f, 0.48f, 0.26f); }

	bool mayRespawn() { return false; }

	// Where the player lands: the middle of the world, standing on the floor.
	static int spawnX() { return BackroomsLevelSource::worldSize() / 2; }
	static int spawnZ() { return BackroomsLevelSource::worldSize() / 2; }
	static int spawnY() { return BackroomsLevelSource::FLOOR_Y + 1; }
};

#endif /*NET_MINECRAFT_WORLD_LEVEL_DIMENSION__BackroomsDimension_H__*/
