#ifndef NET_MINECRAFT_WORLD_LEVEL_DIMENSION__BackroomsDimension_H__
#define NET_MINECRAFT_WORLD_LEVEL_DIMENSION__BackroomsDimension_H__

#include "Dimension.h"
#include "../Level.h"
#include "../storage/LevelData.h"
#include "../levelgen/BackroomsLevelSource.h"

class BackroomsDimension: public Dimension
{
public:
	static const int BACKROOMS = 2;

	BackroomsDimension() {
		id = BACKROOMS;
		hasCeiling = true;
		BackroomsTiles::init(); // make the Backrooms blocks before anything is generated
	}

	ChunkSource* createRandomLevelSource() {
		return new BackroomsLevelSource(level);
	}

	bool isValidSpawn(int x, int z) { return true; }

	// Always the same light level; there is no sun down here.
	float getTimeOfDay(long time, float a) { return 0.5f; }

	// A dull yellow haze.
	Vec3 getFogColor(float td, float a) { return Vec3(0.52f, 0.48f, 0.26f); }

	bool mayRespawn() { return false; }

	// Where the player lands: inside the big open starting room, standing on the floor.
	static int spawnX() { return BackroomsLevelSource::worldSize() / 2 + 3; }
	static int spawnZ() { return BackroomsLevelSource::worldSize() / 2 + 3; }
	static int spawnY() { return BackroomsLevelSource::FLOOR_Y + 1; }

	// True if this level is the Backrooms.
	static bool isBackrooms(Level* l) {
		return l != 0 && l->dimension != 0 && l->dimension->id == BACKROOMS;
	}

	// The game normally picks the spawn point itself, by looking for the highest solid
	// block. In the Backrooms that is the top of the bedrock, so we overwrite it.
	static void fixSpawn(Level* l) {
		if (!isBackrooms(l)) return;
		l->getLevelData()->setSpawn(spawnX(), spawnY(), spawnZ());
	}
};

#endif /*NET_MINECRAFT_WORLD_LEVEL_DIMENSION__BackroomsDimension_H__*/
