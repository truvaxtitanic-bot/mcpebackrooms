#ifndef NET_MINECRAFT_WORLD_LEVEL_LEVELGEN__BackroomsLevelSource_H__
#define NET_MINECRAFT_WORLD_LEVEL_LEVELGEN__BackroomsLevelSource_H__

// Procedural Backrooms generator.
//
// Vertical layout (y = height in blocks):
//   y 0..62   solid unbreakable (keeps the dimension sealed)
//   y 63      floor
//   y 64..66  3 blocks of walking space (hallways are 3 tall)
//   y 67      ceiling (the 4th block up), with light panels in it
//   y 68..127 solid unbreakable
//
// The layout is a pure function of the block position, so the same spot always
// generates the same maze. The world is CHUNK_CACHE_WIDTH chunks wide, which is the
// same size as a normal world.

#include "../chunk/ChunkSource.h"
#include "../chunk/LevelChunk.h"
#include "../tile/Tile.h"
#include "../LevelConstants.h"
#include "../Level.h"

class BackroomsLevelSource: public ChunkSource
{
public:
	static const int FLOOR_Y   = 63;
	static const int CEILING_Y = 67;
	static const int CELL      = 8;   // size of one maze cell in blocks

	BackroomsLevelSource(Level* level)
	:	level(level)
	{
	}

	// Placeholder block choices. Replace these with the Backrooms textures later.
	static int floorTile()   { return Tile::cloth->id; }
	static int wallTile()    { return Tile::sandStone->id; }
	static int ceilingTile() { return Tile::stoneBrick->id; }
	static int lightTile()   { return Tile::lightGem->id; }

	static int worldSize() { return CHUNK_CACHE_WIDTH * 16; }

	// A bit mixer; gives the same number for the same inputs every time.
	static unsigned int hash3(int a, int b, int c) {
		unsigned int h = ((unsigned int)a * 73856093u) ^ ((unsigned int)b * 19349663u) ^ ((unsigned int)c * 83492791u);
		h ^= h >> 13;
		h *= 0x5bd1e995u;
		h ^= h >> 15;
		return h;
	}

	// True if the block column at (wx, wz) is a wall.
	static bool isWall(int wx, int wz) {
		const int size = worldSize();
		if (wx < 1 || wz < 1 || wx >= size - 1 || wz >= size - 1) return true; // outer edge

		const int cx = wx / CELL, cz = wz / CELL;
		const int lx = wx % CELL, lz = wz % CELL;

		if (lx == 0 && lz == 0) return true; // pillars at every cell corner

		// keep the spawn area wide open
		if (nearSpawn(wx, wz)) return false;

		if (lx == 0) {
			bool solid = (hash3(cx, cz, 1) % 100) < 55;
			bool door  = (lz == 3 || lz == 4) && (hash3(cx, cz, 2) % 100) < 75;
			return solid && !door;
		}
		if (lz == 0) {
			bool solid = (hash3(cx, cz, 3) % 100) < 55;
			bool door  = (lx == 3 || lx == 4) && (hash3(cx, cz, 4) % 100) < 75;
			return solid && !door;
		}
		return false;
	}

	static bool nearSpawn(int wx, int wz) {
		const int c = worldSize() / 2;
		int dx = wx - c; if (dx < 0) dx = -dx;
		int dz = wz - c; if (dz < 0) dz = -dz;
		return dx < 14 && dz < 14;
	}

	// True if there is a ceiling light at this block column.
	static bool isLight(int wx, int wz) {
		const int cx = wx / CELL, cz = wz / CELL;
		const int lx = wx % CELL, lz = wz % CELL;
		if (lx < 3 || lx > 4 || lz < 3 || lz > 4) return false;
		return (hash3(cx, cz, 5) % 100) < 70; // some panels are dark
	}

	bool hasChunk(int x, int z) { return true; }

	LevelChunk* create(int x, int z) { return getChunk(x, z); }

	LevelChunk* getChunk(int xOffs, int zOffs) {
		unsigned char* blocks = new unsigned char[LevelChunk::ChunkBlockCount];
		LevelChunk* levelChunk = new LevelChunk(level, blocks, xOffs, zOffs);

		const unsigned char solid = (unsigned char) Tile::unbreakable->id;
		const unsigned char floorT = (unsigned char) floorTile();
		const unsigned char wallT = (unsigned char) wallTile();
		const unsigned char ceilT = (unsigned char) ceilingTile();
		const unsigned char lightT = (unsigned char) lightTile();

		for (int x = 0; x < 16; x++) {
			for (int z = 0; z < 16; z++) {
				const int wx = xOffs * 16 + x;
				const int wz = zOffs * 16 + z;
				const bool wall = isWall(wx, wz);
				const bool light = isLight(wx, wz);

				for (int y = 0; y < 128; y++) {
					const int offs = (z * 16 + x) * 128 + y;
					unsigned char b = 0;
					if (y < FLOOR_Y)       b = solid;
					else if (y == FLOOR_Y) b = floorT;
					else if (y < CEILING_Y) b = wall ? wallT : 0;
					else if (y == CEILING_Y) b = light ? lightT : ceilT;
					else                   b = solid;
					blocks[offs] = b;
				}
			}
		}

		levelChunk->recalcHeightmap();
		return levelChunk;
	}

	void postProcess(ChunkSource* parent, int x, int z) {}

	bool tick() { return false; }

	bool shouldSave() { return false; }

	Biome::MobList getMobsAt(const MobCategory& mobCategory, int x, int y, int z) {
		return Biome::MobList(); // nothing spawns here yet
	}

	std::string gatherStats() { return "BackroomsLevelSource"; }

private:
	Level* level;
};

#endif /*NET_MINECRAFT_WORLD_LEVEL_LEVELGEN__BackroomsLevelSource_H__*/
