#!/usr/bin/env python3
"""
Runs during the build, after build_web.sh has copied mod.zip on top of the game.
It stamps the Backrooms pictures into the game's terrain.png atlas (in squares that are
empty) and writes BackroomsAtlas.h so the C++ code knows which squares were used.

Usage (build_web.sh does this for you):   python3 apply_backrooms.py <game folder>
Uses only Python's built-in libraries, so nothing needs installing.
"""
import os
import sys
import struct
import zlib

SIG = b"\x89PNG\r\n\x1a\n"


def read_png(path):
    """Returns (width, height, RGBA bytes)."""
    data = open(path, "rb").read()
    if data[:8] != SIG:
        raise ValueError("%s is not a PNG" % path)
    pos, idat, plte, trns = 8, b"", None, None
    w = h = bd = ct = il = 0
    while pos < len(data):
        ln = struct.unpack(">I", data[pos:pos + 4])[0]
        typ = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + ln]
        pos += 12 + ln
        if typ == b"IHDR":
            w, h, bd, ct, _, _, il = struct.unpack(">IIBBBBB", body)
        elif typ == b"PLTE":
            plte = body
        elif typ == b"tRNS":
            trns = body
        elif typ == b"IDAT":
            idat += body
        elif typ == b"IEND":
            break
    if bd != 8 or il != 0 or ct not in (0, 2, 3, 4, 6):
        raise ValueError("%s: unsupported PNG kind (bit depth %d, type %d, interlace %d)" % (path, bd, ct, il))
    ch = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[ct]
    stride = w * ch
    raw = zlib.decompress(idat)
    rows, prev, p = [], bytearray(stride), 0
    for _ in range(h):
        f = raw[p]
        cur = bytearray(raw[p + 1:p + 1 + stride])
        p += 1 + stride
        if f == 1:
            for i in range(ch, stride):
                cur[i] = (cur[i] + cur[i - ch]) & 255
        elif f == 2:
            for i in range(stride):
                cur[i] = (cur[i] + prev[i]) & 255
        elif f == 3:
            for i in range(stride):
                a = cur[i - ch] if i >= ch else 0
                cur[i] = (cur[i] + ((a + prev[i]) >> 1)) & 255
        elif f == 4:
            for i in range(stride):
                a = cur[i - ch] if i >= ch else 0
                b = prev[i]
                c = prev[i - ch] if i >= ch else 0
                pa, pb, pc = abs(b - c), abs(a - c), abs(a + b - 2 * c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                cur[i] = (cur[i] + pr) & 255
        rows.append(cur)
        prev = cur
    out = bytearray(w * h * 4)
    o = 0
    for r in rows:
        for x in range(w):
            if ct == 6:
                px = r[x * 4:x * 4 + 4]
            elif ct == 2:
                px = bytes((r[x * 3], r[x * 3 + 1], r[x * 3 + 2], 255))
            elif ct == 0:
                px = bytes((r[x], r[x], r[x], 255))
            elif ct == 4:
                px = bytes((r[x * 2], r[x * 2], r[x * 2], r[x * 2 + 1]))
            else:  # paletted
                i = r[x]
                a = trns[i] if (trns and i < len(trns)) else 255
                px = bytes((plte[i * 3], plte[i * 3 + 1], plte[i * 3 + 2], a))
            out[o:o + 4] = px
            o += 4
    return w, h, out


def write_png(path, w, h, rgba):
    def chunk(t, b):
        c = struct.pack(">I", len(b)) + t + b
        return c + struct.pack(">I", zlib.crc32(t + b) & 0xffffffff)
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        raw += rgba[y * w * 4:(y + 1) * w * 4]
    png = SIG + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
    png += chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b"")
    open(path, "wb").write(png)


def main():
    game = sys.argv[1] if len(sys.argv) > 1 else "."
    mod_dir = os.path.join(game, "textures")
    src_root = os.path.join(game, "src")

    # role -> picture
    roles = [
        ("BR_TEX_FLOOR",    "yellow_wool.png"),
        ("BR_TEX_WALL",     "stripped_bamboo_block.png"),
        ("BR_TEX_CEILING",  "polished_diorite.png"),
        ("BR_TEX_LAMP_ON",  "redstone_lamp_on.png"),
        ("BR_TEX_LAMP_OFF", "redstone_lamp.png"),
    ]

    atlases = []
    for root, _, files in os.walk(os.path.join(game, "data")):
        for f in files:
            if f.lower() == "terrain.png":
                atlases.append(os.path.join(root, f))
    if not atlases:
        print("ERROR: no terrain.png found under %s/data" % game)
        sys.exit(1)

    chosen_first = None
    for path in atlases:
        w, h, px = read_png(path)
        tile = w // 16
        print("Atlas %s  %dx%d  tile size %d" % (path, w, h, tile))

        def empty(idx):
            x0, y0 = (idx % 16) * tile, (idx // 16) * tile
            for y in range(y0, y0 + tile):
                base = (y * w + x0) * 4
                for x in range(tile):
                    if px[base + x * 4 + 3] != 0:
                        return False
            return True

        free = [i for i in range(255, -1, -1) if empty(i)]
        if len(free) >= len(roles):
            chosen = free[:len(roles)]
        else:
            print("WARNING: only %d empty squares; reusing the last squares of the atlas." % len(free))
            chosen = (free + list(range(255, -1, -1)))[:len(roles)]

        for (name, fname), idx in zip(roles, chosen):
            pw, ph, pp = read_png(os.path.join(mod_dir, fname))
            x0, y0 = (idx % 16) * tile, (idx // 16) * tile
            for y in range(tile):
                for x in range(tile):
                    sx, sy = x * pw // tile, y * ph // tile
                    s = (sy * pw + sx) * 4
                    d = ((y0 + y) * w + x0 + x) * 4
                    px[d:d + 4] = pp[s:s + 4]
            print("  %s -> square %d" % (name, idx))
        write_png(path, w, h, px)
        if chosen_first is None:
            chosen_first = chosen

    header = os.path.join(src_root, "world", "level", "tile", "BackroomsAtlas.h")
    os.makedirs(os.path.dirname(header), exist_ok=True)
    with open(header, "w") as fh:
        fh.write("#ifndef NET_MINECRAFT_WORLD_LEVEL_TILE__BackroomsAtlas_H__\n")
        fh.write("#define NET_MINECRAFT_WORLD_LEVEL_TILE__BackroomsAtlas_H__\n")
        for (name, _), idx in zip(roles, chosen_first):
            fh.write("#define %s %d\n" % (name, idx))
        fh.write("#endif\n")
    print("Wrote", header)
    print("Backrooms textures applied.")


main()
